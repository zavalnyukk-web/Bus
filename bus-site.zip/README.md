# Автобус Кунівського ліцею: підключення (близько 20 хвилин, з комп'ютера)

## 1. База даних Firebase (безкоштовно)
1. Зайдіть на console.firebase.google.com, увійдіть через Google, натисніть «Add project», назва будь-яка (наприклад, bus-kuniv). Google Analytics можна вимкнути.
2. Зліва: Build, потім Realtime Database, потім «Create Database». Регіон оберіть europe-west1. Режим: «Locked mode».
3. Відкрийте вкладку «Rules», вставте правила нижче і натисніть Publish. Замініть ТАЄМНИЙ-КЛЮЧ на довгий випадковий рядок з латинських літер і цифр (20 і більше символів), запишіть його.

{
  "rules": {
    "bus": {
      "$k": {
        ".read": "$k === 'ТАЄМНИЙ-КЛЮЧ'",
        ".write": "$k === 'ТАЄМНИЙ-КЛЮЧ'",
        ".validate": "newData.hasChildren(['lat','lng','ts'])"
      }
    }
  }
}

4. На вкладці «Data» скопіюйте адресу бази зверху (виглядає як https://bus-kuniv-default-rtdb.europe-west1.firebasedatabase.app).

## 2. Файл config.js
Відкрийте config.js у Блокноті. Вставте адресу бази в dbUrl і той самий ключ у key. Збережіть.

## 3. Сайт на GitHub Pages
1. На github.com створіть новий репозиторій (кнопка New), назва bus, тип Public.
2. «Add file», потім «Upload files»: завантажте index.html, driver.html, config.js. Натисніть Commit.
3. Settings, потім Pages: Source «Deploy from a branch», гілка main, папка / (root), Save.
4. Через 1-2 хвилини сайт буде за адресою https://zavalnyukk-web.github.io/bus/

## 4. Користування
- Батькам: надсилайте посилання https://zavalnyukk-web.github.io/bus/
- Вам, в автобусі: відкрийте https://zavalnyukk-web.github.io/bus/driver.html на телефоні, у Chrome натисніть меню, «Додати на головний екран». На початку рейсу: «Почати рейс» і дозвольте доступ до місця. У кінці: «Завершити рейс».

## Важливо
- Ключ видно в коді сайту, тож це захист від випадкових людей, а не від зловмисників. Не діліться посиланням на driver.html.
- Погодьте це з директором і водієм. Показуйте місце автобуса лише під час рейсу.
